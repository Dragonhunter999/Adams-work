import os
from random import randint
import pygame


class Settings():                                   # Statische Klasse
    SCREENRECT = pygame.rect.Rect(0, 0, 1200, 600)
    FPS = 60
    PATHFILE = os.path.dirname(os.path.abspath(__file__))
    PATHIMG = os.path.join(PATHFILE, "images")
    x = 0
    @staticmethod
    def get_imagepath(filename):
        return os.path.join(Settings.PATHIMG, filename)


class Charakter(pygame.sprite.Sprite):
    def __init__(self, filename, colorkey=None) -> None:
        super().__init__()
        if colorkey is None:
            self.image = pygame.image.load(Settings.get_imagepath(filename)).convert_alpha()
        else:
            self.image = pygame.image.load(Settings.get_imagepath(filename)).convert()
            self.image.set_colorkey(colorkey)

        self.image = pygame.transform.scale(self.image, (100, 100))

        self.rect = self.image.get_rect()
        self.vel = [0, 0]

    def update(self) -> None:
        self.rect.left += self.vel[0]
        self.rect.top += self.vel[1]
        if self.rect.right >= Settings.SCREENRECT.width or self.rect.left < 0:
            self.vel[0] *= -1
        if self.rect.bottom >= Settings.SCREENRECT.height or self.rect.top < 0:
            self.vel[1] *= -1
        return super().update()


class Game():
    def __init__(self) -> None:
        os.environ['SDL_VIDEO_WINDOW_POS'] = "10, 50"
        pygame.init()                                   # Subsysteme starten
        self.screen = pygame.display.set_mode(Settings.SCREENRECT.size)    # Bildschirm/Fenster dimensionieren
        self.clock = pygame.time.Clock()                     # Taktgeber

        self.all_objekts = pygame.sprite.Group()
        self.all_entitis = pygame.sprite.Group()

        self.background = pygame.image.load(Settings.get_imagepath("background.png")).convert()
        self.background = pygame.transform.scale(self.background, Settings.SCREENRECT.size)
       
        x = 0
        while x < 20:
            self.obstacle = Charakter("slime.png")
            self.obstacle.rect.topleft = (randint(10, Settings.SCREENRECT.width-10), randint(10, Settings.SCREENRECT.height-10))
            self.obstacle.vel =  [randint(-3,-1), randint(1,3)]
            self.all_entitis.add(self.obstacle)
            x = x + 1

        self.objekt1 = Charakter("tnt.gif")
        self.objekt1.rect.right = Settings.SCREENRECT.width
        self.objekt1.rect.bottom = Settings.SCREENRECT.height - 100
        self.objekt1.vel = [0, 0]
        self.all_objekts.add(self.objekt1)

        self.objekt2 = Charakter("melon.png", (0, 0, 0))
        self.objekt2.rect.topleft = (0, 150)
        self.objekt2.vel = [0, 0]
        self.all_objekts.add(self.objekt2)

        self.objekt3 = Charakter("chrome.png", (0, 0, 0))
        self.objekt3.rect.topleft = (200, 100)
        self.objekt3.vel = [0, 0]
        self.all_objekts.add(self.objekt3)
       
        self.objekt4 = Charakter("enderperle.png", (0, 0, 0))
        self.objekt4.rect.topleft = (750, 100)
        self.objekt4.vel = [0, 0]
        self.all_objekts.add(self.objekt4)

        self.objekt5 = Charakter("gras.jpg")
        self.objekt5.rect.right = Settings.SCREENRECT.width -500
        self.objekt5.rect.bottom = Settings.SCREENRECT.height 
        self.objekt5.vel = [0, 0]
        self.all_objekts.add(self.objekt5)

        self.objekt6 = Charakter("dragon.png")
        self.objekt6.rect.right = Settings.SCREENRECT.width -200
        self.objekt6.rect.bottom = Settings.SCREENRECT.height -10
        self.objekt6.vel = [0, 0]
        self.all_objekts.add(self.objekt6)

        self.objekt4 = pygame.sprite.collide_circle(self.obstacle, self.objekt4)
        self.objekt3 = pygame.sprite.collide_circle(self.obstacle, self.objekt3)
        self.objekt1 = pygame.sprite.collide_rect(self.obstacle, self.objekt1)
        self.objekt5 = pygame.sprite.collide_rect(self.obstacle, self.objekt5)
        self.objekt2 = pygame.sprite.collide_mask(self.obstacle, self.objekt2)
        self.objekt6 = pygame.sprite.collide_mask(self.obstacle, self.objekt6)
        
        self.running = True                                  # Flagvariable

    def start(self):
        while self.running:                                  # Hauptprogrammschleife
            self.clock.tick(Settings.FPS)                    # Auf mind. 1/60s takten
            self.watch_for_events()
            self.update()
            self.draw()
            self.collison()

        pygame.quit()                                   # Subssysteme stoppen

    def watch_for_events(self):
        for event in pygame.event.get():            # Einlesen der Message-Queue
            if event.type == pygame.QUIT:           # Ist X angeklickt worden?
                self.running = False                     # Toggle Flag
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    self.running = False

    def update(self):
        self.all_objekts.update()
        self.all_entitis.update()

    def draw(self):
        self.screen.blit(self.background, (0, 0))
        self.all_objekts.draw(self.screen)
        self.all_entitis.draw(self.screen)
        pygame.display.flip()
    
    def collison(self):
        for sprite in self.all_entitis.sprites():
            if pygame.sprite.spritecollideany(sprite, self.all_objekts):
                sprite.kill()


def main():
    game = Game()
    game.start()


if __name__ == "__main__":
    main()

# Leider war ich übervordert das program richtig laut der Aufgaben stellung zulösen aber ich hoffe diese ansatz lösung ist ansatzweise richtig